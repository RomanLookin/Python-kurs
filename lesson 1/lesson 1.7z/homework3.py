#задание 3

var_int=int(input('enter you integer number:'))
var1=var_int*10+var_int
var2=var_int*100+var1
print('{}+{}+{}={}'.format(var_int,var1,var2,var_int+var1+var2))
