#задание 1

var_str='Hello world'
var_int=10
var_list=['fg', 10, 'sfgb', -45.5]
print(var_str+'/n')
print(var_int)
print(var_list)
var_str2=input('enter you string:')
print('you enter:'+var_str2)
var_int2=int(input('enter you number:'))
print('you enter:'+str(var_int2))
var_float=float(input('enter you float'))
print('you enter float:'+str(var_float))